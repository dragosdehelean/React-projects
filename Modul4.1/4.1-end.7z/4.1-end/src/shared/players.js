export const PLAYERS = 
[
  {
    name: "Guil",
    score: 0,
    id: 0
  },
  {
    name: "Treasure",
    score: 0,
    id: 1
  },
  {
    name: "Ashley",
    score: 0,
    id: 2
  },
  {
    name: "James",
    score: 0,
    id: 3
  }
];