import React from 'react';
import Gif from './Gif';

const GifList = props => { 
  
  return(
    <ul className="gif-list">
      {/* <Gif /> */}
    </ul> 
  );
}

export default GifList;
